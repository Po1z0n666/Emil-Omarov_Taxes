package com.example.taxemiltax;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaxEmilTaxApplication {
    public static void main(String[] args) {
        SpringApplication.run(TaxEmilTaxApplication.class, args);
    }
}






