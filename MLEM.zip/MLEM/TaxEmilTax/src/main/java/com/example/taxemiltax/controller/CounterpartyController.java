package com.example.taxemiltax.controller;

import com.example.taxemiltax.model.Counterparty;
import com.example.taxemiltax.service.CounterpartyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class CounterpartyController {
    @Autowired
    private CounterpartyService service;

    @GetMapping("/")
    public String index(Model model, @RequestParam(required = false) String filter, @RequestParam(required = false) String sort) {
        List<Counterparty> counterparties;
        if (filter != null && !filter.isEmpty()) {
            counterparties = service.filterCounterparties(filter);
        } else {
            counterparties = service.getAllCounterparties();
        }
        if (sort != null && !sort.isEmpty()) {
            counterparties = service.sortCounterparties(sort);
        }
        model.addAttribute("counterparties", counterparties);
        return "index";
    }

    @GetMapping("/add")
    public String addCounterpartyForm(Model model) {
        model.addAttribute("counterparty", new Counterparty());
        return "add";
    }

    @PostMapping("/add")
    public String addCounterparty(@ModelAttribute Counterparty counterparty) {
        service.saveCounterparty(counterparty);
        return "redirect:/";
    }

    @GetMapping("/edit/{id}")
    public String editCounterpartyForm(@PathVariable Long id, Model model) {
        Counterparty counterparty = service.getCounterpartyById(id);
        model.addAttribute("counterparty", counterparty);
        return "edit";
    }

    @PostMapping("/edit/{id}")
    public String editCounterparty(@PathVariable Long id, @ModelAttribute Counterparty counterparty) {
        service.saveCounterparty(counterparty);
        return "redirect:/";
    }

    @GetMapping("/delete/{id}")
    public String deleteCounterparty(@PathVariable Long id) {
        service.deleteCounterparty(id);
        return "redirect:/";
    }

    @GetMapping("/about")
    public String about() {
        return "about";
    }

    @GetMapping("/histogram")
    public String histogram(Model model) {
        List<Counterparty> counterparties = service.getAllCounterparties();
        double averageIncome = service.calculateAverageIncome(counterparties);
        double maxIncome = service.calculateMaxIncome(counterparties);
        double minIncome = service.calculateMinIncome(counterparties);
        model.addAttribute("counterparties", counterparties);
        model.addAttribute("averageIncome", averageIncome);
        model.addAttribute("maxIncome", maxIncome);
        model.addAttribute("minIncome", minIncome);
        return "histogram";
    }

    @GetMapping("/view/{id}")
    public String viewCounterparty(@PathVariable Long id, Model model) {
        Counterparty counterparty = service.getCounterpartyById(id);
        model.addAttribute("counterparty", counterparty);
        return "view";
    }
}
