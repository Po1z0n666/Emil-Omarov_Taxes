package com.example.taxemiltax.service;

import com.example.taxemiltax.model.Counterparty;
import com.example.taxemiltax.repository.CounterpartyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CounterpartyService {
    @Autowired
    private CounterpartyRepository repository;

    public List<Counterparty> getAllCounterparties() {
        return repository.findAll();
    }

    public Counterparty saveCounterparty(Counterparty counterparty) {
        return repository.save(counterparty);
    }

    public void deleteCounterparty(Long id) {
        repository.deleteById(id);
    }

    public Counterparty getCounterpartyById(Long id) {
        return repository.findById(id).orElse(null);
    }

    public List<Counterparty> filterCounterparties(String criteria) {
        return repository.findAll().stream()
                .filter(counterparty -> counterparty.getName().contains(criteria) || counterparty.getInn().contains(criteria))
                .collect(Collectors.toList());
    }

    public List<Counterparty> sortCounterparties(String field) {
        List<Counterparty> counterparties = repository.findAll();
        if ("nameAsc".equals(field)) {
            counterparties.sort(java.util.Comparator.comparing(Counterparty::getName));
        } else if ("nameDesc".equals(field)) {
            counterparties.sort(java.util.Comparator.comparing(Counterparty::getName).reversed());
        } else if ("incomeAsc".equals(field)) {
            counterparties.sort(java.util.Comparator.comparingDouble(Counterparty::getIncome));
        } else if ("incomeDesc".equals(field)) {
            counterparties.sort(java.util.Comparator.comparingDouble(Counterparty::getIncome).reversed());
        }
        return counterparties;
    }

    public double calculateAverageIncome(List<Counterparty> counterparties) {
        return counterparties.stream().mapToDouble(Counterparty::getIncome).average().orElse(0);
    }

    public double calculateMaxIncome(List<Counterparty> counterparties) {
        return counterparties.stream().mapToDouble(Counterparty::getIncome).max().orElse(0);
    }

    public double calculateMinIncome(List<Counterparty> counterparties) {
        return counterparties.stream().mapToDouble(Counterparty::getIncome).min().orElse(0);
    }
}
