package com.example.taxemiltax;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaxEmilTaxApplicationTests {

    @Test
    void contextLoads() {
    }

}
